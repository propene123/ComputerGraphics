To run the application navigate into the src directory and double
click on index.html

I have used the cuon-matrix, cuon-utils, initShaders, webgl-debug,
webgl-utils libraries from the practical exercises.
I have also adpated certain parts of the practical examples for my
application.

There are no textures as whenever I attemped to use them the draw
times became incredibly lengthy and animations ran so slow that it
was impossible to use the application (this could have been due
to my laptops integrated graphics not being very powerful) apologies
for this.
